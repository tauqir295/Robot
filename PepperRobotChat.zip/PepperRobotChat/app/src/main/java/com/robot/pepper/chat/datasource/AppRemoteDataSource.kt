package com.robot.pepper.chat.datasource

import com.robot.pepper.chat.datasource.data.RandomJoke
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class AppRemoteDataSource: AppDataSource {

    /**
     *  Using retrofit 2 to fetch data from API.
     *  @params: listener - injecting data source listener
     */
    override fun getRandomJokeFromAPI(listener: AppDataSource.DataSourceListener) {

        // initiating ApiInterface via retrofit
        val apiService = ApiClient.getRetrofitInstance()?.create(ApiInterface::class.java)

        // API call to receive data from API using retrofit
        val call = apiService?.getRandomJoke()

        //queueing the call to listen the api response
        call?.enqueue(object : Callback<RandomJoke> {
            override fun onFailure(call: Call<RandomJoke>, t: Throwable) {
                listener.onError("0",t.printStackTrace().toString()) // passing error code as 0 - can be customized
            }

            override fun onResponse(call: Call<RandomJoke>, response: Response<RandomJoke>) {
                // if API is successful then the status code is 200
                if (response.code() == 200) {
                    val randomJoke = response.body()
                    randomJoke?.let {
                        listener.onSuccess(it) //passig the response body content to listener
                    }
                } else { // for any status other than 200 means API call has failed
                    response.errorBody()?.let {
                        listener.onError(response.code().toString(), it.toString())
                    }
                }
            }
        })
    }
}