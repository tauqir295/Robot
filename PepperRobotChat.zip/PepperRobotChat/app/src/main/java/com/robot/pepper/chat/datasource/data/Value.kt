package com.robot.pepper.chat.datasource.data

import java.io.Serializable

data class Value(
    val categories: List<Any>,
    val id: Int,
    val joke: String
): Serializable