package com.robot.pepper.chat.datasource

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

/**
 * Class for creating Retrofit object using Retrofit.Builder
 * Object instance is used for calling api
 */

class ApiClient {

    companion object {
        private var retrofit: Retrofit? = null

        /**
         * creating the Retrofit object using Retrofit.Builder
         * baseUrl - the url for web api
         * @return:Retrofit - use this returned class to call API
         */
        fun getRetrofitInstance(): Retrofit? {
            if (retrofit == null) {
                retrofit = Retrofit.Builder()
                    .baseUrl("http://api.icndb.com/jokes/")
                    .addConverterFactory(GsonConverterFactory.create())
                    .build()
            }
            return retrofit
        }
    }

}