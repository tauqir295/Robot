package com.robot.pepper.chat.datasource

import com.robot.pepper.chat.datasource.data.RandomJoke
import retrofit2.Call
import retrofit2.http.GET

/**
 * Interface for managing api calls from a single place
 */
interface ApiInterface {

    @GET("random/")
    fun getRandomJoke(): Call<RandomJoke>
}