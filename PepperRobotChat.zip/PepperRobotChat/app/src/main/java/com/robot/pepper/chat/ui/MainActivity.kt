package com.robot.pepper.chat.ui

import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AlertDialog
import com.aldebaran.qi.Future
import com.aldebaran.qi.sdk.QiContext
import com.aldebaran.qi.sdk.QiSDK
import com.aldebaran.qi.sdk.RobotLifecycleCallbacks
import com.aldebaran.qi.sdk.`object`.actuation.Animate
import com.aldebaran.qi.sdk.`object`.actuation.EnforceTabletReachability
import com.aldebaran.qi.sdk.`object`.conversation.*
import com.aldebaran.qi.sdk.builder.*
import com.aldebaran.qi.sdk.design.activity.RobotActivity
import com.robot.pepper.chat.R
import com.robot.pepper.chat.datasource.*
import com.robot.pepper.chat.datasource.data.RandomJoke
import kotlinx.android.synthetic.main.activity_main.*

/**
 * Activity class - this ia the entry point of app.
 * Contains methods to do launch the app and robot functionalities
 */
class MainActivity : RobotActivity(), RobotLifecycleCallbacks {

    private val TAG = "MainActivity"

    // Store the Animate action.
    private var animate: Animate? = null

    // Store qiContext
    private var qiContext: QiContext? = null

    // Store the EnforceTabletReachability action
    private var enforceTabletReachability: EnforceTabletReachability? = null

    // Store the enforceTabletReachability action's future
    private var enforceTabletReachabilityFuture: Future<Void>? = null

    // Store the QiChatbot
    private var qiChatbot: QiChatbot? = null

    // Store the chat action future
    private var chatFuture: Future<Void>? = null

    // Store the goodbye bookmark.
    private var goodByeBookmark: Bookmark? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Register the RobotLifecycleCallbacks to this Activity.
        QiSDK.register(this, this)

        buttonB.setOnClickListener {
            getRandomJoke()
        }

        buttonA.setOnClickListener {
            if (enforceTabletReachabilityFuture == null) {
                    // The EnforceTabletReachability action is not running
                    startEnforceTabletReachability()
            } else {
                // The EnforceTabletReachability is running
                enforceTabletReachabilityFuture?.requestCancellation()
            }
        }
    }

    /**
     * retrofit API call for fetching jokes
     */
    fun getRandomJoke() {

        // set the progress bar while API call is in progress
        progressBar.visibility = View.VISIBLE

        // creating AppRepository object by passing AppRemoteDataSource via dependency injection
        val appRepository = AppRepository.getInstance(AppRemoteDataSource())

        // initiating the API call
        appRepository.getRandomJokeFromAPI(object : AppDataSource.DataSourceListener{
            override fun onSuccess(data: Any) {
                val randomJoke = data as RandomJoke

                runOnUiThread {
                    editText.setText(randomJoke.value.joke)
                    progressBar.visibility = View.GONE
                }
            }

            override fun onError(errorCode: String, errorMessage: String) {
                progressBar.visibility = View.GONE
                showErrorDialog()
            }

        })

    }

    override fun onDestroy() {
        // Unregister the RobotLifecycleCallbacks for this Activity.
        QiSDK.unregister(this, this)
        super.onDestroy()
    }

    override fun onRobotFocusGained(qiContext: QiContext?) {
        // Store qiContext
        this.qiContext = qiContext

        loadBookmark(qiContext)

        enableButtonAInteractionWithRobot(qiContext)
    }

    /**
     * methods for loading the bookmarks from raw file
     * @param: [qiContext] - used initializing the QiSDK class elements
     */
    fun loadBookmark(qiContext: QiContext?) {

        // create topic from the file
        val talkTopic = TopicBuilder.with(qiContext)
            .withResource(R.raw.custom)
            .build()

        talkTopic?.let {

            // Get the bookmarks from the topic.
            val welcomeBookmark = it.bookmarks?.get(getString(R.string.welcoming))
            goodByeBookmark = it.bookmarks?.get(getString(R.string.goodbye))

            // build the qiChatbot with topic
            qiChatbot = QiChatbotBuilder.with(qiContext).withTopic(it).build()

            // build the chat with [QiChatbot]
            val chat = ChatBuilder.with(qiContext) .withChatbot(qiChatbot) .build()
            chat?.let {
                // Go to the proposal bookmark when the Chat action starts.
                it.addOnStartedListener { sayProposal(welcomeBookmark) }

                //run the chat asynchronously
                chatFuture = it.async().run()
            }
        }
    }

    /**
     * Enable tha chat bot to read bookmark content
     */
    fun sayProposal(bookmark: Bookmark?) {
        qiChatbot?.goToBookmark(
            bookmark,
            AutonomousReactionImportance.HIGH,
            AutonomousReactionValidity.IMMEDIATE
        )
    }

    /**
     * methods for initializing the mobile button interaction to robot via EnforceTabletReachability.
     * @param:qiContext - used initializing the EnforceTabletReachability
     */
    fun enableButtonAInteractionWithRobot(qiContext: QiContext?) {
        // Build EnforceTabletReachability action.
        enforceTabletReachability = EnforceTabletReachabilityBuilder.with(qiContext).build()

        // On position reached listener
        enforceTabletReachability?.addOnPositionReachedListener {
            Log.i(TAG, "The tablet now is in position.")
        }

    }

    override fun onRobotFocusLost() {

        // Remove on started listeners from the animate action.
        animate?.removeAllOnStartedListeners()

        // Remove the QiContext.
        this.qiContext = null

        // Remove all the listeners
        enforceTabletReachability?.removeAllOnPositionReachedListeners()

    }

    override fun onRobotFocusRefused(reason: String?) {
    }

    /**
     * This function is used for animating the pepper robot
     */
    fun animateRobot() {

        // Create an animation.
        val animation = AnimationBuilder.with(qiContext) // Create the builder with the context.
            .withResources(R.raw.bow_animation) // Set the animation resource.
            .build() // Build the animation.

        // Create an animate action.
        animate = AnimateBuilder.with(qiContext) // Create the builder with the context.
            .withAnimation(animation) // Set the animation.
            .build() // Build the animate action.

        animate?.let {
            // Add an on started listener to the animate action.
            it.addOnStartedListener {
                val message = "Animation started."
                Log.i(TAG, message)
            }

            // Run the animate action asynchronously.
            val animateFuture = it.async()?.run()

            animateFuture?.let {
                it.thenConsume { future ->
                    if (future.isSuccess) {
                        val message = "Animation finished with success."
                        Log.i(TAG, message)
                    } else if (future.hasError()) {
                        val message = "Animation finished with error."
                        Log.e(TAG, message, future.error)
                    }
                }
            }
        }
    }

    /**
     * Method to let the mobile device interact with robot.
     * EnforceTabletReachability helps to manage NetworkOnMainThreadException
     */
    fun startEnforceTabletReachability() {
        // Run the action asynchronously
        enforceTabletReachabilityFuture = enforceTabletReachability?.async()?.run()

        // Handle the action's end
        enforceTabletReachabilityFuture?.thenConsume { future ->

            // Log the eventual errors
            if (future.hasError()) {
                Log.e(TAG, "The EnforceTabletReachability action finished with error.", future.error)
                enforceTabletReachabilityFuture?.requestCancellation()
            } else {
                Log.i(TAG, "The EnforceTabletReachability action has finished.")

                sayProposal(goodByeBookmark)
                animateRobot()
            }
        }
    }

    /**
     * show error dialog in case of API call fails
     */
    fun showErrorDialog(){
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.api_failed))
            .setMessage(getString(R.string.something_went_wrong))
            .setPositiveButton(getString(R.string.ok)) { dialog, _ ->
                dialog.dismiss()
            }
            .setCancelable(false)
            .show()
    }
}
