package com.robot.pepper.chat.datasource.data

import java.io.Serializable

data class RandomJoke(
    val type: String,
    val value: Value
): Serializable