package com.robot.pepper.chat.datasource

import android.annotation.SuppressLint

/**
 * Generic class API call.
 * This can be used for all the classes whichever extends AppDataSource
 */
class AppRepository(private val dataSource: AppDataSource) : AppDataSource {

    companion object {
        @SuppressLint("StaticFieldLeak")
        private var INSTANCE: AppRepository? = null

        /**
         * create new instance
         */
        fun getInstance(dataSource: AppDataSource) =
            INSTANCE ?: synchronized(AppRepository::class.java) {
                INSTANCE ?: AppRepository(dataSource)
                    .also { INSTANCE = it }
            }

        /**
         * destroy the instance
         */
        @JvmStatic
        fun destroyInstance() {
            INSTANCE = null
        }
    }

    /**
     * middle layer method to pass on listener to remote data source from fragment/activity
     */
    override fun getRandomJokeFromAPI(listener: AppDataSource.DataSourceListener) {
        dataSource.getRandomJokeFromAPI(listener)
    }
}