package com.robot.pepper.chat.datasource

/**
 * Interface for passing data to-and-from API call via DataSourceListener
 */
interface AppDataSource {
    fun getRandomJokeFromAPI(listener: DataSourceListener)

    interface DataSourceListener {
        fun onSuccess(data: Any)
        fun onError(errorCode: String, errorMessage: String)
    }
}